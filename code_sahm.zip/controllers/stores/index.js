module.exports = {...require("./stats"),
    ...require("./banners"),
    ...require("./notifications"),
    ...require("./monthly_fees"),
    ...require("./stores"),
    ...require("./ads")
}