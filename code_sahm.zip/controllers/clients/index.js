module.exports = {
    ...require("./cart"),
    ...require("./clients"),
    ...require("./favourites")
}