const StoreFeePaymentStatus = {PENDING:"PENDING",APPROVED:"APPROVED",REJECTED:"REJECTED"}

module.exports = StoreFeePaymentStatus;