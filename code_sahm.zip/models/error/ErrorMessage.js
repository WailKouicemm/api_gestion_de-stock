class ErrorMessage {
    message_en;
    message_ar;
    constructor(message_en,message_ar) {
        this.message_en = message_en;
        this.message_ar = message_ar;
    }
}
module.exports = ErrorMessage;